from __future__ import annotations

import asyncio
import base64
import contextlib
import json
import re
import time
from datetime import timedelta
from contextlib import AsyncExitStack
from typing import Awaitable, Callable

from app.core import config
from ..core.guards import verify_tutor_action_access
from ..services.ai_gateway import generate_audio, get_live_client, live_api_available
from ..services.cbse_exercises import build_exercise_solution
from ..services.rag_service import retrieve_context as rag_get_context
from ..services.rag_service import retrieve_context
from ..services.session_service import session_service
from ..tutor_brain.curriculum import get_grade_curriculum

try:
    from app.agents.diagnostic_agent import DiagnosticAgent
    from app.agents.orchestrator import Orchestrator
    from app.agents.proctor_agent import ProctorAgent
    from app.agents.teacher_agent import TutorAgent
    from app.models.session import StudentSession, utc_now
except ModuleNotFoundError:
    from ..agents.diagnostic_agent import DiagnosticAgent
    from ..agents.orchestrator import Orchestrator
    from ..agents.proctor_agent import ProctorAgent
    from ..agents.teacher_agent import TutorAgent
    from ..models.session import StudentSession, utc_now

try:
    from google.genai import types as live_types
except ImportError:  # pragma: no cover - optional dependency
    live_types = None


EventSink = Callable[[dict], Awaitable[None]]

LIVE_INPUT_SAMPLE_RATE = 16000
LIVE_OUTPUT_SAMPLE_RATE = 24000
CLASS_SESSION_MINUTES = 45

HINDI_CLASS_TUTOR_PROMPT = (
    "You are NOT an AI assistant, and you are forbidden from reading the provided text chunks verbatim. "
    "Instead, you are an incredibly energetic, passionate, and world-class human Mathematics teacher "
    "conducting a lively classroom session. Your voice must sound warm, enthusiastic, and animated.\n\n"
    "CRITICAL TEACHING RULES:\n"
    "1. DYNAMIC REWRITING: Read the textbook context silently to understand the math rule, "
    "but translate it entirely into your own casual, natural, conversational teaching voice. "
    "Never say 'According to the text' or 'The PDF states'. Speak as if the knowledge is entirely in your own brain.\n"
    "2. HUMAN CADENCE & FILLERS: Use natural human conversational phrases to keep things lively. "
    "Sprinkle in energetic phrases like: 'Check this out!', 'Look at this carefully, okay?', 'Now, here is where it gets interesting!', "
    "'Right?', 'Makes sense?'.\n"
    "3. SIMPLIFY WITH ANALOGIES: If the textbook context contains a dry mathematical definition, "
    "instantly explain it using a fun, real-world visual analogy before looking at the equations.\n"
    "4. SOCRATIC PAUSING: Do not lecture for more than 3 to 4 sentences at a time. Explain one tiny "
    "piece of the concept, then pause completely and throw a quick, energetic question back to the student "
    "to check their understanding.\n"
    "5. LANGUAGE BOUNDARY (HINDI MODE): If the language is Hindi, deliver this "
    "passionate performance entirely in fluid, natural Hindi speech. Speak like a popular, engaging Indian "
    "coaching class teacher—expressive, encouraging, keeping core math keywords (like 'Radius', 'Tangent', 'Hypotenuse') "
    "in English, but explaining everything else in beautiful, rhythmic Hindi."
)


class LiveTutorConnectionError(RuntimeError):
    pass


class VoiceProcessor:
    """Simple VAD gate for forwarding voice chunks to the AI gateway."""

    def __init__(self, *, silence_threshold: int = 18, min_stream_interval_seconds: float = 0.025):
        self.silence_threshold = max(1, int(silence_threshold))
        self.min_stream_interval_seconds = max(0.0, float(min_stream_interval_seconds))
        self.vad_is_active = False
        self._last_stream_at = 0.0

    def _is_probably_silent_pcm(self, audio_bytes: bytes) -> bool:
        if len(audio_bytes) < 2:
            return True

        sample_count = min(len(audio_bytes) // 2, 800)
        if sample_count <= 0:
            return True

        total = 0
        peak = 0
        for index in range(sample_count):
            offset = index * 2
            sample = int.from_bytes(audio_bytes[offset : offset + 2], "little", signed=True)
            magnitude = abs(sample)
            total += magnitude
            peak = max(peak, magnitude)

        threshold = self.silence_threshold
        return peak < threshold or (total / sample_count) < (threshold / 2)

    def process_chunk(self, audio_bytes: bytes) -> bool:
        self.vad_is_active = not self._is_probably_silent_pcm(audio_bytes)
        if not self.vad_is_active:
            return False

        now = time.monotonic()
        if now - self._last_stream_at < self.min_stream_interval_seconds:
            return False
        self._last_stream_at = now
        return True


def _normalize_teaching_language(value: object) -> str:
    normalized = str(value or "").strip().lower().replace("_", "-")
    if normalized in {"hi", "hindi", "hi-in"}:
        return "hi-IN"
    if normalized in {"gu", "gujarati", "gu-in"}:
        return "gu-IN"
    return "en-IN"


def _language_instruction(language: str) -> str:
    if language == "hi-IN":
        return (
            "LANGUAGE STYLE: Speak entirely in fluid, natural Hindi using clear Devanagari phrasing. "
            "Do not use full English sentences. Keep core mathematics terms in English when they match CBSE usage: "
            "probability, outcome, sample space, event, formula, theorem, equation, numerator, denominator, "
            "factor, HCF, LCM, triangle, coordinate, Circles, Radius, Tangent, Hypotenuse, chapter names, symbols, and formulas. "
            "Embed those English math terms naturally inside Hindi sentences. "
            "Speak like a patient Indian human tutor: warm, natural, slightly slow, with clear pauses after key ideas and questions. "
            "Board labels must use actual math symbols (√, π, ×). For your spoken audio, ALWAYS spell out symbols in words (e.g. 'square root' instead of 'sqrt', 'squared' instead of '^2', 'pi' instead of 'π') so the TTS engine pronounces them correctly."
        )
    if language == "gu-IN":
        return (
            "LANGUAGE STYLE: Speak in Gujarati/Gujlish. Keep every mathematics term in English: "
            "probability, outcome, sample space, event, formula, theorem, equation, numerator, denominator, "
            "factor, HCF, LCM, triangle, coordinate, chapter names, symbols, and formulas. "
            "Board labels must use actual math symbols (√, π, ×). For your spoken audio, ALWAYS spell out symbols in words (e.g. 'square root' instead of 'sqrt', 'squared' instead of '^2', 'pi' instead of 'π') so the TTS engine pronounces them correctly."
        )
    return (
        "LANGUAGE STYLE: Speak in clear Indian English. Keep board labels and all mathematics notation in English using actual math symbols (√, π, ×). "
        "For your spoken audio, ALWAYS spell out symbols in words (e.g. 'square root' instead of 'sqrt', 'squared' instead of '^2', 'pi' instead of 'π') so the TTS engine pronounces them correctly."
    )


def _speech_language_code(language: str) -> str | None:
    if language == "hi-IN":
        return "hi"
    if language == "gu-IN":
        return "gu"
    if language == "en-IN":
        return "en"
    return None


class LiveTutorBridge:
    def __init__(self, session_id: str, emit_event: EventSink):
        self.session_id = session_id
        self.emit_event = emit_event
        self._client = get_live_client()
        self._exit_stack = AsyncExitStack()
        self._live_session = None
        self._receiver_task: asyncio.Task | None = None
        self._send_lock = asyncio.Lock()
        self._assistant_started = False
        self._assistant_transcript = ""
        self._assistant_fallback = ""
        self._assistant_audio_emitted = False
        self._input_transcript = ""
        self._board_context_lines: list[str] = []
        self._active_mode: str | None = None
        self._active_context: dict | None = None
        self._pending_transport: str | None = None
        self._closed = False
        self.orchestrator = Orchestrator()
        self.tutor_agent = TutorAgent()
        self.diagnostic_agent = DiagnosticAgent()
        self.proctor_agent = ProctorAgent()
        self.student_session = StudentSession(
            session_id=session_id,
            active_phase="teaching",
        )

    def update_context(self, payload: dict) -> None:
        context = payload.get("context") if isinstance(payload.get("context"), dict) else {}
        if context:
            self._active_context = {**(self._active_context or {}), **context}
            if context.get("grade") is not None:
                with contextlib.suppress(TypeError, ValueError):
                    self.student_session.grade = int(context["grade"])
            if context.get("exam"):
                self.student_session.exam = "jee" if str(context.get("exam")).lower() == "jee" else "cbse"
            if context.get("teaching_language") or context.get("language"):
                self.student_session.teaching_language = _normalize_teaching_language(
                    context.get("teaching_language") or context.get("language")
                )
            chapter = context.get("chapter") or context.get("chapter_name")
            topic = context.get("topic") or context.get("concept")
            if chapter:
                self.student_session.chapter_name = str(chapter)
            if topic:
                self.student_session.current_topic = str(topic)

        lines: list[str] = []
        whiteboard = payload.get("whiteboard") if isinstance(payload.get("whiteboard"), dict) else {}
        for item in payload.get("visible_steps") or []:
            if isinstance(item, str) and item.strip():
                lines.append(item.strip())
        for item in whiteboard.get("chalk_lines") or []:
            if isinstance(item, str) and item.strip():
                lines.append(item.strip())
        actions = payload.get("whiteboard_actions")
        if not isinstance(actions, list):
            actions = whiteboard.get("actions")
        if isinstance(actions, list):
            for action in actions:
                if not isinstance(action, dict):
                    continue
                text = self._action_text(action)
                if text:
                    lines.append(text)

        problem = str(whiteboard.get("problem") or "").strip()
        if problem:
            self.student_session.current_problem = {"prompt": problem}

        cleaned: list[str] = []
        seen: set[str] = set()
        for line in lines:
            normalized = " ".join(line.split())
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            cleaned.append(normalized[:240])
        self._board_context_lines = cleaned[-14:]

    @property
    def available(self) -> bool:
        return bool(live_api_available() and self._client is not None and live_types is not None)

    async def connect(self) -> bool:
        if not self.available:
            await self.emit_event({"type": "live_error", "content": "Gemini Live API is not configured or unavailable."})
            return False

        session_record = session_service.get_session(self.session_id)
        if not session_record:
            return False

        connect_config = self._build_connect_config(session_record)
        connect_cm = self._client.aio.live.connect(
            model=config.GEMINI_LIVE_MODEL,
            config=connect_config,
        )
        self._live_session = await self._exit_stack.enter_async_context(connect_cm)
        self._receiver_task = asyncio.create_task(self._receive_loop())
        await self.emit_event(
            {
                "type": "live_status",
                "content": "Gemini Live session connected.",
                "mode": "native-audio",
            }
        )
        
        return True

    async def close(self) -> None:
        if self._closed:
            return

        self._closed = True
        if self._receiver_task:
            self._receiver_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._receiver_task
        await self._exit_stack.aclose()

    async def send_text_turn(
        self,
        message: str,
        *,
        mode: str | None = None,
        context: dict | None = None,
    ) -> None:
        if mode:
            self._active_mode = mode
        if isinstance(context, dict) and context:
            self._active_context = dict(context)
        self._reset_pending_turn(transport="text")
        agent_turn = await self._process_agent_turn(
            message,
            transport="text",
            append_user=True,
            append_assistant=True,
            mode=mode,
            context=context,
        )
        await self._emit_agent_turn(agent_turn)

    async def current_state(self) -> dict:
        await self._sync_student_session()
        return self._build_agent_state([])

    def _board_context_text(self) -> str:
        if not self._board_context_lines:
            problem = getattr(self.student_session, "current_problem", {}) or {}
            prompt = problem.get("prompt") if isinstance(problem, dict) else None
            return str(prompt or "").strip()
        return "\n".join(f"- {line}" for line in self._board_context_lines)

    async def send_audio_chunk(self, audio_bytes: bytes) -> None:
        if not self._live_session or not live_types:
            raise RuntimeError("Gemini Live session is not ready")

        if self._pending_transport != "audio":
            self._reset_pending_turn(transport="audio")

        try:
            async with self._send_lock:
                await self._live_session.send_realtime_input(
                    audio=live_types.Blob(
                        data=audio_bytes,
                        mime_type=f"audio/pcm;rate={LIVE_INPUT_SAMPLE_RATE}",
                    )
                )
        except Exception as error:
            await self._handle_live_transport_error(error)

    async def send_encoded_audio(self, audio_bytes: bytes, mime_type: str = "audio/webm") -> None:
        if not self._live_session or not live_types:
            raise RuntimeError("Gemini Live session is not ready")

        if self._pending_transport != "audio":
            self._reset_pending_turn(transport="audio")

        try:
            async with self._send_lock:
                await self._live_session.send_realtime_input(
                    audio=live_types.Blob(
                        data=audio_bytes,
                        mime_type=mime_type,
                    )
                )
        except Exception as error:
            await self._handle_live_transport_error(error)

    async def send_video_frame(self, frame_bytes: bytes, mime_type: str = "image/jpeg") -> None:
        if not self._live_session or not live_types:
            return

        blob = live_types.Blob(data=frame_bytes, mime_type=mime_type)
        try:
            async with self._send_lock:
                try:
                    await self._live_session.send_realtime_input(video=blob)
                except Exception:
                    await self._live_session.send_realtime_input(image=blob)
        except Exception as error:
            await self._handle_live_transport_error(error)

    async def end_audio_stream(self) -> None:
        if not self._live_session:
            return

        try:
            async with self._send_lock:
                await self._live_session.send_realtime_input(audio_stream_end=True)
        except Exception as error:
            await self._handle_live_transport_error(error)

    async def _handle_live_transport_error(self, error: Exception) -> None:
        with contextlib.suppress(Exception):
            await self.close()
        self._live_session = None
        raise LiveTutorConnectionError(str(error)) from error

    def _build_connect_config(self, session_record):
        memory_context = session_service.build_memory_context(self.session_id)
        topic_title = (
            getattr(self.student_session, "current_topic", None)
            or session_record.topic_title
            or "CBSE Mathematics"
        )
        chapter_title = (
            getattr(self.student_session, "chapter_name", None)
            or session_record.topic_title
            or topic_title
            or "Mathematics Overview"
        )
        board_context = self._board_context_text()
        raw_phase = getattr(self.student_session, "active_phase", "teaching")
        phase = str(getattr(raw_phase, "value", raw_phase) or "teaching").strip().lower()

        source_material = self._firebase_curriculum_context(
            grade=int(getattr(session_record, "grade", 10) or 10),
            exam=str(getattr(self.student_session, "exam", "cbse") or "cbse"),
            chapter=chapter_title,
            topic=topic_title,
        ) or retrieve_context(
            query=topic_title,
            exam_type=str(getattr(self.student_session, "exam", "cbse") or "cbse"),
            grade=int(getattr(session_record, "grade", 10) or 10),
            chapter=chapter_title,
            phase=phase,
        )
        curriculum_grounding = (
            f"Board: {session_record.board}\n"
            f"Subject: {session_record.subject}\n"
            f"Grade: {session_record.grade}\n"
            f"Current chapter: {chapter_title}\n"
            f"Current topic: {topic_title}"
        )

        if source_material:
            source_material = source_material[:1800]
            curriculum_grounding += (
                "\n\nSource material from NCERT / CBSE PDF curriculum:\n"
                "Use this textbook-backed content when teaching this chapter.\n"
                f"{source_material}"
            )

            self.tutor_agent.SYSTEM_PROMPT,
            grade=session_record.grade,
            exam=(getattr(self.student_session, "exam", "cbse") or "cbse").upper(),
            is_new_chapter=not bool(getattr(session_record, "transcript", None)),
            chapter_name=chapter_title,
            current_topic=topic_title,
            rag_context=source_material or "No RAG context provided.",
            phase=phase,
        

        agenda_list = getattr(self.student_session, "agenda", [])
        agenda_text = "\n".join(f"{i+1}. {topic}" for i, topic in enumerate(agenda_list)) if agenda_list else f"1. {topic_title}"
        teaching_language = _normalize_teaching_language(getattr(self.student_session, "teaching_language", "en-IN"))
        language_instruction = _language_instruction(teaching_language)
        speech_language_code = _speech_language_code(teaching_language)
        class_mode_prompt = (
            f"{HINDI_CLASS_TUTOR_PROMPT}\n\n"
            if teaching_language == "hi-IN"
            else ""
        )

        system_prompt = (
            f"{class_mode_prompt}"
            f"{resolved_system_prompt}\n\n"
            "LIVE AUDIO & CLASSROOM RULES:\n"
            "1. YOU ARE THE DRIVER: You are leading a continuous 45-minute class. DO NOT wait for the user to explicitly ask to move on.\n"
            "2. AUTO-TRANSITION: When a concept is fully explained and the student understands, seamlessly and automatically transition to the next topic on the agenda below.\n"
            f"CLASS AGENDA (Teach sequentially):\n{agenda_text}\n\n"
            "3. TEACHING FLOW: For each concept: Introduce it -> Explain the formula -> Walk through step-by-step examples -> Solve an exercise from the textbook with them.\n"
            "4. Keep each spoken turn short, slow, and interactive. Pause to ensure they are following before proceeding to the next step.\n"
            "5. Do not mention internal routing, diagnostics, or hidden nudges.\n\n"
            "FOLLOW-UP DOUBTS: If the student asks a doubt or follow-up question, pause the planned lesson, "
            "answer that doubt directly with one small example, update the whiteboard, then connect the answer "
            "back to the current chapter/topic before continuing.\n"
            "READ PROBLEMS ALOUD FIRST: When giving an exercise or example problem, ALWAYS read the full question text clearly to the student first, then explain in the active teaching language that you will solve it step by step. In Hindi mode, use natural Devanagari Hindi such as 'बेटा, अब solution धीरे-धीरे समझते हैं.'\n"
            "For vague follow-ups like 'this step', 'that formula', or 'why did we do this', treat the question "
            "as referring to the CURRENT BLACKBOARD CONTEXT below. If the blackboard context is insufficient, "
            "ask one short clarification or counter-question before solving. Do not switch to Real Numbers, "
            "Euclid's division lemma, or any other chapter unless that is the current chapter or the student "
            "explicitly asks for it.\n"
            f"{language_instruction}\n"
            f"Current chapter focus: {chapter_title}\n"
            f"Current topic focus: {topic_title}\n"
            f"Current blackboard context:\n{board_context or 'No visible blackboard lines were provided.'}\n\n"
            f"Current classroom memory:\n{memory_context}\n\n"
            f"Curriculum grounding:\n{curriculum_grounding}"
        )

        return live_types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            system_instruction=live_types.Content(
                parts=[live_types.Part(text=system_prompt)]
            ),
            speech_config=live_types.SpeechConfig(
                language_code=speech_language_code,
                voice_config=live_types.VoiceConfig(
                    prebuilt_voice_config=live_types.PrebuiltVoiceConfig(
                        voice_name=config.GEMINI_LIVE_VOICE
                    )
                ),
            ),
            input_audio_transcription=live_types.AudioTranscriptionConfig(
                language_codes=[teaching_language]
            ),
            output_audio_transcription=live_types.AudioTranscriptionConfig(
                language_codes=[teaching_language]
            ),
            realtime_input_config=live_types.RealtimeInputConfig(
                activity_handling=live_types.ActivityHandling.START_OF_ACTIVITY_INTERRUPTS,
                turn_coverage=live_types.TurnCoverage.TURN_INCLUDES_ALL_INPUT,
                automatic_activity_detection=live_types.AutomaticActivityDetection(
                    prefix_padding_ms=300,
                    silence_duration_ms=1800,
                )
            ),
            session_resumption=live_types.SessionResumptionConfig(handle=None),
            context_window_compression=live_types.ContextWindowCompressionConfig(
                trigger_tokens=24000,
                sliding_window=live_types.SlidingWindow(target_tokens=12000),
            ),
        )

    async def _process_agent_turn(
        self,
        message: str,
        *,
        transport: str,
        append_user: bool,
        append_assistant: bool,
        mode: str | None = None,
        context: dict | None = None,
    ) -> dict:
        await self._sync_student_session()
        effective_mode = mode or self._active_mode
        effective_context = context if isinstance(context, dict) else self._active_context
        if not isinstance(effective_context, dict):
            effective_context = {}
        if effective_context.get("grade") is not None:
            try:
                self.student_session.grade = int(effective_context["grade"])
            except (TypeError, ValueError):
                pass
        self.student_session.exam = "jee" if str(effective_context.get("exam", self.student_session.exam)).lower() == "jee" else "cbse"
        if effective_context.get("teaching_language") or effective_context.get("language"):
            self.student_session.teaching_language = _normalize_teaching_language(
                effective_context.get("teaching_language") or effective_context.get("language")
            )
        if effective_context.get("chapter") or effective_context.get("chapter_name"):
            self.student_session.chapter_name = str(effective_context.get("chapter") or effective_context.get("chapter_name"))
        if effective_context.get("topic") or effective_context.get("concept"):
            self.student_session.current_topic = str(effective_context.get("topic") or effective_context.get("concept"))
        action = self._extract_action_from_message(message)

        if effective_mode == "class":
            self._ensure_class_timer(action)
            if self._is_class_time_over() and action != "start":
                return self._class_expired_turn()

        route = await self.orchestrator.route_message(
            self.session_id,
            message,
            mode=effective_mode,
            context=effective_context,
        )
        self.student_session.current_topic = self._resolve_current_topic()
        nudge = None
        diagnostic_result = None
        proctor_payload = None
        tutor_payload = {"advance_topic": False}
        rag_context = ""

        if effective_mode == "class":
            topic = self._resolve_current_topic()
            board_context = self._board_context_text()
            if board_context:
                nudge = (
                    "CURRENT BLACKBOARD CONTEXT:\n"
                    f"{board_context}\n"
                    "Answer student doubts against this blackboard and the current chapter. "
                    "If the question is ambiguous and the board context is not enough, ask one concise clarification. "
                    "Do not jump to Euclid's division lemma or another chapter unless explicitly requested."
                )
            normalized_exam = "jee" if str(self.student_session.exam or "").lower() == "jee" else "cbse"
            raw_phase = getattr(self.student_session, "active_phase", "teaching")
            phase = str(getattr(raw_phase, "value", raw_phase) or "teaching").strip().lower()
            source_hint = (
                "JEE PYQ patterns, solved examples, and problem solving strategies"
                if normalized_exam == "jee"
                else "NCERT textbook concept explanations, worked examples, and exercise questions"
            )
            query = (
                f"Grade {getattr(self.student_session, 'grade', 10)} "
                f"{normalized_exam.upper()} Mathematics "
                f"chapter {self.student_session.chapter_name or topic} "
                f"topic {topic} {message} "
                f"{source_hint}"
            ).strip()
            try:
                rag_context = self._firebase_curriculum_context(
                    grade=int(getattr(self.student_session, "grade", 10) or 10),
                    exam=normalized_exam,
                    chapter=self.student_session.chapter_name or topic,
                    topic=topic,
                ) or rag_get_context(
                    query=query,
                    exam_type=normalized_exam,
                    k=6,
                    grade=int(getattr(self.student_session, "grade", 10) or 10),
                    chapter=self.student_session.chapter_name or topic,
                    phase=phase,
                )
            except Exception as error:
                print(f"Live RAG lookup failed ({type(error).__name__}): {error}")
                rag_context = ""

        if route == "proctor_agent":
            proctor_payload = await self.proctor_agent.process_message(
                self.student_session,
                message,
            )
            spoken_response = proctor_payload.get("spoken_response", "")
            whiteboard_actions = proctor_payload.get("whiteboard_actions", [])
        elif route == "diagnostic_agent":
            diagnostic_result = await self.diagnostic_agent.evaluate_answer(
                self.student_session,
                message,
                correct_answer="42",
            )
            nudge = diagnostic_result.get("hidden_nudge")
            if (
                effective_mode == "class"
                and phase != "teaching"
                and action in {"start", "next", "continue", "repeat", "refresh_problem", "previous_problem", "next_exercise", "next_pdf_exercise"}
            ):
                candidates = self._extract_problem_candidates(rag_context)
                if candidates:
                    base_prob = candidates[self.student_session.questions_asked % len(candidates)]
                    nudge = "\n".join(
                        part
                        for part in [
                            nudge,
                            "SYSTEM INSTRUCTION: Solve at least one exercise question fully on the whiteboard "
                            "using short sequential 'draw_text' steps. "
                            f"Use this question if relevant: {base_prob}",
                        ]
                        if part
                    )
            tutor_payload = await self.tutor_agent.process_message(
                self.student_session,
                message,
                diagnostic_nudge=nudge,
                rag_context=rag_context,
            )
            spoken_response = tutor_payload.get("spoken_response", "")
            whiteboard_actions = tutor_payload.get("whiteboard_actions", [])
        else:
            # âœ… FIX 2: Explicitly order the AI Agent to solve the problem on the board
            if (
                effective_mode == "class"
                and phase != "teaching"
                and action in {"start", "next", "continue", "repeat", "refresh_problem", "previous_problem", "next_exercise", "next_pdf_exercise"}
            ):
                candidates = self._extract_problem_candidates(rag_context)
                if candidates:
                    base_prob = candidates[self.student_session.questions_asked % len(candidates)]
                    nudge = (
                        (nudge or "")
                        + "\nSYSTEM INSTRUCTION: Solve at least one exercise question fully on the whiteboard "
                        "using short sequential 'draw_text' steps. "
                        f"Use this question if relevant: {base_prob}"
                    )

            tutor_payload = await self.tutor_agent.process_message(
                self.student_session,
                message,
                diagnostic_nudge=nudge,
                rag_context=rag_context,
            )
            spoken_response = tutor_payload.get("spoken_response", "")
            whiteboard_actions = tutor_payload.get("whiteboard_actions", [])

        expanded_actions = []
        for action in whiteboard_actions:
            if isinstance(action, dict) and str(action.get("action", "")).lower() == "draw_shape" and action.get("content"):
                try:
                    from ..services.geometry_translator import translate_diagram_to_primitives_async
                    prims = await translate_diagram_to_primitives_async(action["content"])
                    expanded_actions.extend(prims)
                except Exception as e:
                    print(f"Diagram translation error: {e}")
            else:
                expanded_actions.append(action)
        whiteboard_actions = expanded_actions

        if route != "proctor_agent" and tutor_payload.get("advance_topic"):
            try:
                verify_tutor_action_access(
                    user_id=str(effective_context.get("user_id") or "").strip() or None,
                    requested_grade=getattr(self.student_session, "grade", None),
                    session=self.student_session,
                    action="next_topic",
                    topic_slug=effective_context.get("chapter_slug"),
                    exam=getattr(self.student_session, "exam", "cbse"),
                )
            except Exception as error:
                detail = getattr(error, "detail", None) or "Access locked. Active subscription required for the next chapter."
                spoken_response = str(detail)
                whiteboard_actions = [
                    *whiteboard_actions,
                    {"action": "draw_text", "content": str(detail)},
                ]
            else:
                next_topic = self.orchestrator._advance_to_next_topic(self.student_session)
                whiteboard_actions = [
                    *whiteboard_actions,
                    {"action": "draw_text", "content": f"Topic complete. Next topic: {next_topic}"},
                ]

        whiteboard_actions = self._prepare_problem_whiteboard_actions(
            topic=self._resolve_current_topic(),
            actions=whiteboard_actions,
            variation=self.student_session.questions_asked,
            rag_context=rag_context,
        )
        self.student_session.questions_asked += 1
        whiteboard_actions = self._ensure_board_header_actions(whiteboard_actions)

        raw_phase = getattr(self.student_session, "active_phase", "teaching")
        phase = str(getattr(raw_phase, "value", raw_phase) or "teaching").strip().lower()

        if phase != "teaching" and not self._has_action_text(whiteboard_actions):
            whiteboard_actions = self._pyq_problem_actions(
                topic=self._resolve_current_topic(),
                variation=self.student_session.questions_asked,
                rag_context=rag_context,
            )
            whiteboard_actions = self._ensure_board_header_actions(whiteboard_actions)
        spoken_response = self._spoken_from_actions(
            spoken_response=spoken_response,
            whiteboard_actions=whiteboard_actions,
            topic=self._resolve_current_topic(),
        )
        state = self._build_agent_state(whiteboard_actions)

        if append_user:
            session_service.append_turn(
                self.session_id,
                "user",
                message,
                transport=transport,
            )

        if append_assistant and spoken_response:
            session_service.append_turn(
                self.session_id,
                "assistant",
                spoken_response,
                transport=transport,
            )

        session_service.update_session_metadata(
            self.session_id,
            {
                "student_session": self.student_session.model_dump(mode="json"),
                "last_agent_route": route,
                "last_diagnostic": diagnostic_result,
                "last_proctor": proctor_payload,
                "whiteboard_actions": whiteboard_actions,
                "whiteboard": state["whiteboard"],
            },
        )
        await self.orchestrator.set_session(self.session_id, self.student_session)

        return {
            "route": route,
            "spoken_response": spoken_response,
            "whiteboard_actions": whiteboard_actions,
            "diagnostic": diagnostic_result,
            "state": state,
            "archive": self._session_archive(),
            "session_time_left_seconds": self._class_time_left_seconds() if effective_mode == "class" else None,
            "session_duration_seconds": int(self.student_session.class_duration_minutes * 60) if effective_mode == "class" else None,
            "session_expired": False,
        }

    async def _emit_agent_turn(self, agent_turn: dict) -> None:
        await self._ensure_assistant_started()
        await self.emit_event(
            {
                "type": "assistant_text",
                "content": agent_turn["spoken_response"],
            }
        )
        await self.emit_event(
            {
                "type": "whiteboard_actions",
                "actions": agent_turn["whiteboard_actions"],
            }
        )
        await self.emit_event(
            {
                "type": "assistant_turn_complete",
                "spoken_response": agent_turn["spoken_response"],
                "whiteboard_actions": agent_turn["whiteboard_actions"],
                "state": agent_turn["state"],
                "archive": agent_turn["archive"],
                "session_time_left_seconds": agent_turn.get("session_time_left_seconds"),
                "session_duration_seconds": agent_turn.get("session_duration_seconds"),
                "session_expired": agent_turn.get("session_expired", False),
            }
        )
        self._pending_transport = None
        self._assistant_started = False
        self._assistant_transcript = ""
        self._assistant_fallback = ""
        self._input_transcript = ""

    async def _sync_student_session(self) -> None:
        session = await self.orchestrator.get_session(self.session_id)
        if session is None:
            session = await self.orchestrator.set_session(self.session_id, self.student_session)
        self.student_session = session
        session_record = session_service.get_session(self.session_id)
        if session_record and session_record.topic_title and not self.student_session.current_topic:
            self.student_session.current_topic = session_record.topic_title
        if (
            session_record
            and session_record.topic_title
            and str(self.student_session.chapter_name or "").strip() in {"", "Sets"}
        ):
            self.student_session.chapter_name = session_record.topic_title
        if session_record and session_record.grade:
            self.student_session.grade = int(session_record.grade)

    def _resolve_current_topic(self) -> str:
        if self.student_session.current_topic:
            return str(self.student_session.current_topic)
        if self.student_session.agenda and 0 <= self.student_session.current_topic_index < len(self.student_session.agenda):
            return str(self.student_session.agenda[self.student_session.current_topic_index])
        return str(self.student_session.chapter_name or "Current Topic")

    def _ensure_board_header_actions(self, actions: list[dict]) -> list[dict]:
        chapter = str(self.student_session.chapter_name or "Current Chapter")
        topic = self._resolve_current_topic()
        has_chapter = False
        has_topic = False
        for action in actions:
            text = self._action_text(action).lower()
            if text.startswith("chapter:"):
                has_chapter = True
            if text.startswith("topic:"):
                has_topic = True

        header: list[dict] = []
        if not has_chapter:
            header.append({"action": "draw_text", "content": f"Chapter: {chapter}"})
        if not has_topic:
            header.append({"action": "draw_text", "content": f"Topic: {topic}"})
        if not header:
            return actions
        return [*header, *actions]

    def _build_agent_state(self, whiteboard_actions: list[dict]) -> dict:
        chalk_lines = []
        for action in whiteboard_actions:
            if not isinstance(action, dict):
                continue
            action_name = str(action.get("action") or "").strip().lower()
            if action_name in {"clear", "clear_board", "erase", "reset_board"}:
                continue
            content = (
                action.get("content")
                or action.get("text")
                or action.get("value")
                or action.get("message")
                or action.get("expression")
                or action.get("label")
            )
            if isinstance(content, str) and content.strip():
                chalk_lines.append(content.strip())

        chapter_title = self.student_session.chapter_name or self._resolve_current_topic()
        topic_title = self._resolve_current_topic()

        return {
            "stage": self.student_session.active_phase,
            "topic_title": topic_title,
            "difficulty_level": self.student_session.difficulty_level,
            "mistake_history": self.student_session.mistake_history,
            "current_problem": self.student_session.current_problem,
            "whiteboard_actions": whiteboard_actions,
            "whiteboard": {
                "title": f"{chapter_title} | {topic_title}",
                "subtitle": "Arvind Sir's smart blackboard",
                "chalk_lines": chalk_lines,
                "actions": whiteboard_actions,
            },
        }

    def _session_archive(self) -> list[dict]:
        session_record = session_service.get_session(self.session_id)
        return session_service.list_sessions(
            session_record.student_id if session_record else "local-student",
            session_record.grade if session_record else None,
        )

    def _reset_pending_turn(self, transport: str) -> None:
        self._pending_transport = transport
        self._assistant_started = False
        self._assistant_transcript = ""
        self._assistant_audio_emitted = False
        self._input_transcript = ""

    async def _receive_loop(self) -> None:
        try:
            async for message in self._live_session.receive():
                await self._handle_message(message)
        except asyncio.CancelledError:  # pragma: no cover - expected on shutdown
            raise
        except Exception as error:  # pragma: no cover - network dependent
            await self.emit_event(
                {
                    "type": "live_error",
                    "content": f"Gemini Live session stopped: {error}",
                }
            )

    async def _handle_message(self, message) -> None:
        if message.session_resumption_update:
            update = message.session_resumption_update
            updates = {
                "live_resumable": bool(update.resumable),
                "live_last_consumed_client_message_index": update.last_consumed_client_message_index,
            }
            if update.new_handle:
                updates["live_resumption_handle"] = update.new_handle
            session_service.update_session_metadata(self.session_id, updates)

        if message.go_away:
            await self.emit_event(
                {
                    "type": "live_warning",
                    "content": "Gemini Live will reconnect soon.",
                    "time_left": message.go_away.time_left,
                }
            )

        server_content = getattr(message, "server_content", None)
        if not server_content:
            return

        input_transcription = getattr(server_content, "input_transcription", None)
        if input_transcription and input_transcription.text:
            self._input_transcript = self._merge_transcript(
                self._input_transcript,
                input_transcription.text,
            )
            await self.emit_event(
                {
                    "type": "transcript",
                    "content": self._input_transcript,
                    "finished": bool(input_transcription.finished),
                }
            )

        output_transcription = getattr(server_content, "output_transcription", None)
        if output_transcription and output_transcription.text:
            await self._ensure_assistant_started()
            delta = self._delta_text(self._assistant_transcript, output_transcription.text)
            if delta:
                self._assistant_transcript += delta
                await self.emit_event({"type": "assistant_text", "content": delta})

        audio_data, sample_rate = self._extract_live_audio(message, server_content)
        if audio_data:
            await self._ensure_assistant_started()
            self._assistant_audio_emitted = True
            await self.emit_event(
                {
                    "type": "live_audio",
                    "data": base64.b64encode(audio_data).decode("ascii"),
                    "sample_rate": sample_rate,
                }
            )

        if getattr(server_content, "turn_complete", False):
            await self._finalize_turn()

    async def _ensure_assistant_started(self) -> None:
        if self._assistant_started:
            return

        self._assistant_started = True
        await self.emit_event({"type": "assistant_turn_start"})

    def _extract_live_audio(self, message, server_content) -> tuple[bytes, int]:
        direct_data = getattr(message, "data", None)
        if isinstance(direct_data, (bytes, bytearray)):
            return bytes(direct_data), LIVE_OUTPUT_SAMPLE_RATE
        if isinstance(direct_data, str):
            with contextlib.suppress(Exception):
                return base64.b64decode(direct_data), LIVE_OUTPUT_SAMPLE_RATE

        model_turn = getattr(server_content, "model_turn", None)
        parts = getattr(model_turn, "parts", None) or []
        for part in parts:
            inline_data = getattr(part, "inline_data", None) or getattr(part, "inlineData", None)
            if inline_data is None:
                continue
            mime_type = str(getattr(inline_data, "mime_type", "") or getattr(inline_data, "mimeType", ""))
            if "audio" not in mime_type.lower():
                continue
            sample_rate = LIVE_OUTPUT_SAMPLE_RATE
            rate_match = re.search(r"rate=(\d+)", mime_type)
            if rate_match:
                with contextlib.suppress(ValueError):
                    sample_rate = int(rate_match.group(1))
            data = getattr(inline_data, "data", None)
            if isinstance(data, (bytes, bytearray)):
                return bytes(data), sample_rate
            if isinstance(data, str):
                with contextlib.suppress(Exception):
                    return base64.b64decode(data), sample_rate

        return b"", LIVE_OUTPUT_SAMPLE_RATE

    async def _finalize_turn(self) -> None:
        agent_turn = None

        if not self._assistant_transcript and self._assistant_fallback:
            await self._ensure_assistant_started()
            self._assistant_transcript = self._assistant_fallback
            await self.emit_event(
                {"type": "assistant_text", "content": self._assistant_fallback}
            )

        if self._pending_transport == "audio" and self._input_transcript.strip():
            agent_turn = await self._process_agent_turn(
                self._input_transcript.strip(),
                transport="bidi",
                append_user=True,
                append_assistant=False,
            )
            await self.emit_event(
                {
                    "type": "user_turn",
                    "content": self._input_transcript.strip(),
                    "transport": "bidi",
                }
            )
            await self.emit_event(
                {
                    "type": "whiteboard_actions",
                    "actions": agent_turn["whiteboard_actions"],
                }
            )

            if not self._assistant_transcript.strip():
                await self._ensure_assistant_started()
                self._assistant_transcript = agent_turn["spoken_response"]
                await self.emit_event(
                    {
                        "type": "assistant_text",
                        "content": self._assistant_transcript,
                    }
                )

        if self._assistant_transcript.strip() and not self._assistant_audio_emitted:
            with contextlib.suppress(Exception):
                teaching_language = _normalize_teaching_language(
                    getattr(self.student_session, "teaching_language", "en-IN")
                )
                audio_bytes = await generate_audio(
                    _sanitize_for_speech(self._assistant_transcript.strip()),
                    voice_name=config.GEMINI_LIVE_VOICE,
                    language_code=_speech_language_code(teaching_language),
                )
                if audio_bytes:
                    self._assistant_audio_emitted = True
                    await self.emit_event(
                        {
                            "type": "live_audio",
                            "data": base64.b64encode(audio_bytes).decode("ascii"),
                            "sample_rate": LIVE_OUTPUT_SAMPLE_RATE,
                        }
                    )

        if self._assistant_transcript.strip():
            session_service.append_turn(
                self.session_id,
                "assistant",
                self._assistant_transcript.strip(),
                transport="bidi" if self._pending_transport == "audio" else "text",
            )

        state = agent_turn["state"] if agent_turn else self._build_agent_state([])
        await self.emit_event(
            {
                "type": "assistant_turn_complete",
                "spoken_response": self._assistant_transcript.strip(),
                "whiteboard_actions": agent_turn["whiteboard_actions"] if agent_turn else [],
                "state": state,
                "archive": self._session_archive(),
                "session_time_left_seconds": agent_turn.get("session_time_left_seconds") if agent_turn else None,
                "session_duration_seconds": agent_turn.get("session_duration_seconds") if agent_turn else None,
                "session_expired": agent_turn.get("session_expired", False) if agent_turn else False,
            }
        )
        self._pending_transport = None
        self._assistant_started = False
        self._assistant_transcript = ""
        self._assistant_fallback = ""
        self._assistant_audio_emitted = False
        self._input_transcript = ""

    def _merge_transcript(self, current: str, incoming: str) -> str:
        incoming = incoming.strip()
        if not current:
            return incoming
        if incoming.startswith(current):
            return incoming
        if current.endswith(incoming):
            return current
        return f"{current} {incoming}".strip()

    def _delta_text(self, current: str, incoming: str) -> str:
        incoming = incoming.strip()
        if not incoming:
            return ""
        if not current:
            return incoming
        if incoming.startswith(current):
            return incoming[len(current) :].lstrip()
        if current.endswith(incoming):
            return ""
        return incoming

    def _action_text(self, action: dict[str, object]) -> str:
        action_name = str(action.get("action") or "").strip().lower()
        if action_name in {"clear", "clear_board", "erase", "reset_board", "draw_image"}:
            return ""
        text = (
            action.get("content")
            or action.get("text")
            or action.get("value")
            or action.get("message")
            or action.get("expression")
            or action.get("label")
            or ""
        )
        return str(text).strip()

    def _spoken_from_actions(
        self,
        spoken_response: str,
        whiteboard_actions: list[dict[str, object]],
        topic: str,
    ) -> str:
        spoken = str(spoken_response or "").strip()
        if spoken:
            return spoken
        lines = [self._action_text(action) for action in whiteboard_actions if isinstance(action, dict)]
        lines = [line for line in lines if line]
        if lines:
            return " ".join(lines[:4])
        if _normalize_teaching_language(getattr(self.student_session, "teaching_language", "en-IN")) == "hi-IN":
            return (
                f"बेटा, {topic} के current board steps पूरे हो गए। "
                "अब अगला point धीरे-धीरे समझते हैं।"
            )
        return (
            f"We finished the current board steps for {topic}. "
            "Click Next when you are ready for the next explanation."
        )

    def _is_greeting_line(self, text: str) -> bool:
        lowered = text.lower()
        return any(
            phrase in lowered
            for phrase in (
                "welcome",
                "hello",
                "good morning",
                "good evening",
                "welcome back",
            )
        )

    def _is_symbolic_math(self, text: str) -> bool:
        value = str(text or "").strip()
        lowered = value.lower()
        if not value:
            return False

        keyword_hits = (
            "subset",
            "superset",
            "union",
            "intersection",
            "cartesian",
            "roster",
            "set-builder",
            "domain",
            "range",
        )
        if any(keyword in lowered for keyword in keyword_hits):
            return True

        if any(token in value for token in ("=", "<=", ">=", "->", "=>", "^", "|", "{", "}")):
            return True

        if re.search(r"\b\d+\s*[-+*/]\s*\d+\b", value):
            return True

        if re.search(r"\(\s*[A-Za-z0-9]+\s*,\s*[A-Za-z0-9]+\s*\)", value):
            return True

        return False

    def _is_equation_line(self, text: str) -> bool:
        value = str(text or "").strip()
        if not value:
            return False
        if "=" in value or "<=" in value or ">=" in value:
            return True
        if re.search(r"\b\d+\s*[-+*/]\s*\d+\b", value):
            return True
        if re.search(r"\b[A-Za-z]\s*\^", value):
            return True
        if re.search(r"\b[A-Za-z]\s*=\s*", value):
            return True
        return False

    def _needs_problem_board(self, actions: list[dict[str, object]]) -> bool:
        if not actions:
            return True

        # âœ… FIX 3: Trust the AI! If it returns more than 2 steps, it's solving the math!
        if len(actions) > 2:
            return False

        has_equation_action = any(
            str(action.get("action", "")).strip().lower()
            in {"write_equation", "plot_curve", "draw_coordinate_axes", "draw_line", "draw_circle"}
            for action in actions
            if isinstance(action, dict)
        )
        if has_equation_action:
            return False

        equation_count = 0
        symbolic_count = 0
        prose_count = 0
        for action in actions:
            text = self._action_text(action)
            if not text:
                continue
            if self._is_equation_line(text):
                equation_count += 1
            elif self._is_symbolic_math(text):
                symbolic_count += 1
            elif len(text.split()) >= 10:
                prose_count += 1

        if equation_count >= 1 and prose_count == 0:
            return False
        if symbolic_count >= 2:
            return False
        if symbolic_count == 1 and prose_count == 0:
            return False
        return True

    def _has_action_text(self, actions: list[dict[str, object]]) -> bool:
        return any(self._action_text(action) for action in actions if isinstance(action, dict))

    def _extract_problem_candidates(self, rag_context: str, limit: int = 8) -> list[str]:
        if not isinstance(rag_context, str) or not rag_context.strip():
            return []

        candidates: list[str] = []
        seen: set[str] = set()
        lines = re.split(r"[\r\n]+", rag_context)
        for raw_line in lines:
            line = str(raw_line or "").strip()
            if not line:
                continue

            line = re.sub(r"^\s*(q(?:uestion)?|ex(?:ample)?)\s*[\d.:-]*\s*", "", line, flags=re.IGNORECASE)
            line = re.sub(r"\s+", " ", line).strip(" -:;")
            lowered = line.lower()
            if len(line) < 14 or len(line) > 220:
                continue
            if lowered.startswith("this theorem can be proved") or lowered.startswith("proof"):
                continue
            if lowered.endswith(("such", "therefore", "hence")):
                continue
            if not (
                "?" in line
                or any(
                    token in lowered
                    for token in (
                        "solve",
                        "find",
                        "evaluate",
                        "prove",
                        "show",
                        "simplify",
                        "determine",
                        "calculate",
                    )
                )
            ):
                continue

            key = lowered[:180]
            if key in seen:
                continue
            seen.add(key)
            candidates.append(line)
            if len(candidates) >= limit:
                break
        return candidates

    def _firebase_curriculum_context(self, *, grade: int, exam: str, chapter: str, topic: str) -> str:
        try:
            curriculum = get_grade_curriculum(int(grade or 10), "jee" if str(exam).lower() == "jee" else "cbse")
            chapters = curriculum.get("chapters") if isinstance(curriculum, dict) else []
            if not isinstance(chapters, list) or not chapters:
                return ""

            chapter_l = str(chapter or "").strip().lower()
            topic_l = str(topic or "").strip().lower()
            chapter_match = None
            for item in chapters:
                if not isinstance(item, dict):
                    continue
                title = str(item.get("title") or item.get("chapter") or "").strip()
                slug = str(item.get("slug") or "").strip()
                title_l = title.lower()
                slug_l = slug.lower()
                if chapter_l and (chapter_l in title_l or title_l in chapter_l or chapter_l == slug_l):
                    chapter_match = item
                    break
                if topic_l and (topic_l in title_l or topic_l == slug_l):
                    chapter_match = item
                    break

            if not isinstance(chapter_match, dict):
                return ""

            lines: list[str] = []
            lines.append(f"Chapter: {chapter_match.get('title') or chapter_match.get('chapter') or chapter}")
            if chapter_match.get("summary"):
                lines.append(f"Summary: {chapter_match.get('summary')}")
            if chapter_match.get("teaching_anchor"):
                lines.append(f"Anchor: {chapter_match.get('teaching_anchor')}")
            if chapter_match.get("classroom_goal"):
                lines.append(f"Goal: {chapter_match.get('classroom_goal')}")
            for concept in chapter_match.get("concepts", [])[:6]:
                if not isinstance(concept, dict):
                    continue
                if concept.get("title"):
                    lines.append(f"Concept: {concept.get('title')}")
                if concept.get("definition"):
                    lines.append(f"Definition: {concept.get('definition')}")
                if concept.get("explanation"):
                    lines.append(f"Explanation: {concept.get('explanation')}")
                for bw in (concept.get("board_work") or [])[:4]:
                    lines.append(str(bw))
                for example in (concept.get("ncert_examples") or [])[:4]:
                    if isinstance(example, dict) and example.get("prompt"):
                        lines.append(f"Exercise question: {example.get('prompt')}")
                    for step in (example.get("steps") or [])[:5]:
                        lines.append(f"Step: {step}")
            context = "\n".join(str(line).strip() for line in lines if str(line).strip())
            return context if len(context) >= 200 else ""
        except Exception:
            return ""

    def _generate_similar_problem(self, problem: str, seed: int) -> str:
        if not problem:
            return "Solve a similar variation for this concept."

        delta = (abs(int(seed)) % 3) + 1

        def _replace(match: re.Match) -> str:
            value = int(match.group(0))
            adjusted = value + delta if value >= 0 else value - delta
            return str(adjusted)

        mutated = re.sub(r"(?<![A-Za-z])\d+(?![A-Za-z])", _replace, problem)
        if mutated == problem:
            return f"Solve a similar textbook variation of: {problem}"
        return mutated

    # âœ… FIX 4: Entirely removed fake dummy steps!
    def _pyq_problem_actions(self, topic: str, rag_context: str, variation: int = 0) -> list[dict]:
        candidates = self._extract_problem_candidates(rag_context)

        if candidates:
            base_problem = candidates[variation % len(candidates)]
        else:
            base_problem = f"Solve one step-by-step problem based on {topic or 'the current topic'}."
            try:
                from ..tutor_brain.curriculum import get_chapter_position
                from ..services.cbse_exercises import load_chapter_pdf_exercises
                grade = int(getattr(self.student_session, "grade", 10) or 10)
                exam = str(getattr(self.student_session, "exam", "cbse") or "cbse")
                chapter_title = self.student_session.chapter_name or topic
                ch_idx, _ = get_chapter_position(grade, chapter_title, exam)
                if ch_idx > 0:
                    real_ex = load_chapter_pdf_exercises(grade, ch_idx, chapter_title)
                    if real_ex:
                        base_problem = str(real_ex[variation % len(real_ex)].get("prompt") or base_problem)
            except Exception as e:
                print(f"Fallback exercise retrieval failed: {e}")

        if variation % 3 == 2:
            prompt = self._generate_similar_problem(base_problem, variation + 1)
        elif len(candidates) > 1:
            prompt = candidates[(variation + 1) % len(candidates)]
        else:
            prompt = base_problem

        solved = build_exercise_solution(
            {
                "chapter_title": topic or "Mathematics",
                "exercise": "Practice",
                "number": str(variation + 1),
                "prompt": prompt,
            }
        )
        solved_steps = [str(step).strip() for step in solved.get("steps", []) if str(step).strip()]
        answer = str(solved.get("answer") or "").strip()

        actions: list[dict] = [
            {"action": "draw_text", "content": f"Problem: {prompt}"},
        ]
        for index, step in enumerate(solved_steps[:8], start=1):
            actions.append({"action": "draw_text", "content": f"Step {index}: {step}"})
        if answer:
            actions.append({"action": "draw_text", "content": f"Final answer: {answer}"})
        return actions

    def _prepare_problem_whiteboard_actions(
        self,
        topic: str,
        actions: list[dict[str, object]],
        variation: int,
        rag_context: str = "",
    ) -> list[dict]:
        cleaned: list[dict] = []
        raw_phase = getattr(self.student_session, "active_phase", "teaching")
        phase = str(getattr(raw_phase, "value", raw_phase) or "teaching").strip().lower()

        for action in actions:
            if not isinstance(action, dict):
                continue
            action_name = str(action.get("action", "")).strip()
            if not action_name:
                continue
            text = self._action_text(action)
            if text and self._is_greeting_line(text):
                continue
            is_text_action = action_name.lower() in {"write", "write_text", "add_text", "text", "draw_text"}
            if phase != "teaching" and text and is_text_action and len(text.split()) >= 28 and not self._is_equation_line(text):
                structured = re.match(r"(?i)^(step\s*\d+|problem:|final answer:|source:|chapter:|topic:)", text)
                if not structured:
                    continue
            if action_name.lower() in {"write", "write_text", "add_text", "text"} and not text:
                continue
            cleaned.append(dict(action))

        if phase != "teaching" and self._needs_problem_board(cleaned):
            return self._pyq_problem_actions(topic=topic, variation=variation, rag_context=rag_context)
        return cleaned

    def _extract_action_from_message(self, message: str) -> str:
        text = str(message or "").strip()
        lowered = text.lower()
        if lowered in {"start", "begin"}:
            return "start"
        if lowered in {"next", "next_step", "next topic", "next_topic"}:
            return "next"
        if text.startswith("{") and text.endswith("}"):
            try:
                payload = json.loads(text)
                if isinstance(payload, dict):
                    return str(payload.get("action", "")).strip().lower()
            except json.JSONDecodeError:
                return ""
        return ""

    def _ensure_class_timer(self, action: str) -> None:
        if action == "start" or self.student_session.class_started_at is None:
            self.student_session.class_started_at = utc_now()
            self.student_session.class_duration_minutes = CLASS_SESSION_MINUTES

    def _class_time_left_seconds(self) -> int:
        if self.student_session.class_started_at is None:
            return int(CLASS_SESSION_MINUTES * 60)
        total_seconds = int(self.student_session.class_duration_minutes * 60)
        elapsed_seconds = int((utc_now() - self.student_session.class_started_at).total_seconds())
        return max(0, total_seconds - elapsed_seconds)

    def _is_class_time_over(self) -> bool:
        if self.student_session.class_started_at is None:
            return False
        return utc_now() >= self.student_session.class_started_at + timedelta(
            minutes=self.student_session.class_duration_minutes
        )

    def _class_expired_turn(self) -> dict:
        if getattr(self.student_session, "teaching_language", "en-IN") == "hi-IN":
            spoken_response = (
                f"बेटा, आज की {self.student_session.class_duration_minutes}-minute class यहीं पूरी होती है। "
                "बहुत अच्छा काम किया। आज के notes revise करना, फिर नई class में आगे बढ़ेंगे।"
            )
        else:
            spoken_response = (
                f"Our {self.student_session.class_duration_minutes}-minute class session is complete for today. "
                "Great effort. Please review today's notes and start a new class to continue."
            )
        whiteboard_actions = [
            {"action": "draw_text", "content": f"Session complete ({self.student_session.class_duration_minutes} minutes)"},
            {"action": "draw_text", "content": "Review notes and start a new class session."},
        ]
        state = self._build_agent_state(whiteboard_actions)
        return {
            "route": "tutor_agent",
            "spoken_response": spoken_response,
            "whiteboard_actions": whiteboard_actions,
            "diagnostic": None,
            "state": state,
            "archive": self._session_archive(),
            "session_time_left_seconds": 0,
            "session_duration_seconds": int(self.student_session.class_duration_minutes * 60),
            "session_expired": True,
        }
